def str_is_blank(string: str) -> bool:
    return bool(not string or not string.strip())
